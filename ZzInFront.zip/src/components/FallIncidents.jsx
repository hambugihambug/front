import React, { useState, useEffect } from 'react';
import { Bar } from 'react-chartjs-2';
import axios from 'axios';

const FallIncidents = () => {
    const [incidents, setIncidents] = useState([]);
    const [chartData, setChartData] = useState({});
    const [chartOptions, setChartOptions] = useState({});

    useEffect(() => {
        axios
            .get('/fall-incidents')
            .then((response) => {
                setIncidents(response.data);
            })
            .catch((error) => {
                console.error('Error fetching data: ', error);
            });
    }, []);

    useEffect(() => {
        // 그래프 데이터 생성 로직
    }, [incidents]);

    return (
        <div className="fall-incidents-container">
            <h1>낙상 사고 관리</h1>

            <div
                style={{
                    display: 'flex',
                    gap: '20px',
                    margin: '20px',
                }}
            >
                {/* 왼쪽: 사고 목록 */}
                <div
                    style={{
                        flex: '1',
                        backgroundColor: 'white',
                        padding: '20px',
                        borderRadius: '8px',
                        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                    }}
                >
                    <h2 style={{ marginBottom: '15px' }}>낙상 사고 목록</h2>
                    <div style={{ maxHeight: '500px', overflowY: 'auto' }}>
                        <table
                            style={{
                                width: '100%',
                                borderCollapse: 'collapse',
                            }}
                        >
                            <thead>
                                <tr
                                    style={{
                                        backgroundColor: '#f5f5f5',
                                        borderBottom: '1px solid #ddd',
                                    }}
                                >
                                    <th style={{ padding: '12px', textAlign: 'left' }}>사고 ID</th>
                                    <th style={{ padding: '12px', textAlign: 'left' }}>환자 정보</th>
                                    <th style={{ padding: '12px', textAlign: 'left' }}>발생 일시</th>
                                    <th style={{ padding: '12px', textAlign: 'left' }}>사고 여부</th>
                                </tr>
                            </thead>
                            <tbody>
                                {incidents.map((incident) => (
                                    <tr
                                        key={incident.accident_id}
                                        style={{
                                            borderBottom: '1px solid #eee',
                                            '&:hover': { backgroundColor: '#f9f9f9' },
                                        }}
                                    >
                                        <td style={{ padding: '12px' }}>{incident.accident_id}</td>
                                        <td style={{ padding: '12px' }}>
                                            {incident.patient_name} ({incident.patient_id})
                                        </td>
                                        <td style={{ padding: '12px' }}>
                                            {new Date(incident.accident_date).toLocaleString('ko-KR')}
                                        </td>
                                        <td style={{ padding: '12px' }}>
                                            {incident.accident_YN === 1 ? '발생' : '미발생'}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* 오른쪽: 그래프 */}
                <div
                    style={{
                        flex: '1',
                        backgroundColor: 'white',
                        padding: '20px',
                        borderRadius: '8px',
                        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                    }}
                >
                    <h2 style={{ marginBottom: '15px' }}>시간대별 낙상 사고 발생 현황</h2>
                    <div style={{ height: '400px' }}>
                        <Bar data={chartData} options={chartOptions} />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default FallIncidents;
